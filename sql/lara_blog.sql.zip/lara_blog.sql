-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2016 at 01:24 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lara_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2016_03_22_041657_create_users_table', 1),
('2016_03_22_122816_create_posts_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
`id` int(10) unsigned NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `body`, `user_id`, `created_at`, `updated_at`) VALUES
(28, 'what''s up guyzzzz', 7, '2016-04-09 08:02:46', '2016-04-09 08:02:46'),
(31, 'Life is a gift never to give up.Never give up. If you just hang in there, if you just consistently keep moving forward with a positive attitude magic happens, miracle do happen', 7, '2016-04-09 08:15:15', '2016-04-09 08:15:15'),
(32, 'Hello there...', 6, '2016-04-09 08:53:04', '2016-04-09 08:53:04'),
(36, 'hello guyzzzzzzzzz...', 7, '2016-04-09 22:07:47', '2016-04-09 22:07:47'),
(37, '<script>alert(''fghgfh'');</script>', 7, '2016-04-10 00:05:21', '2016-04-10 00:05:21'),
(41, 'hello world... uhuuuuuuu', 8, '2016-04-10 01:15:55', '2016-04-10 01:18:01'),
(42, 'new post ...', 8, '2016-04-10 01:28:27', '2016-04-10 01:28:27'),
(43, 'another post', 8, '2016-04-10 01:28:41', '2016-04-10 01:28:41'),
(44, 'create post', 8, '2016-04-10 01:30:01', '2016-04-10 01:30:01'),
(45, 'second one', 8, '2016-04-10 01:30:45', '2016-04-10 01:30:45'),
(46, 'great', 8, '2016-04-10 04:12:27', '2016-04-10 04:12:27'),
(47, 'Ohhh !!! oh my goodness !!!!!! What the heck is this', 5, '2016-04-10 04:35:04', '2016-04-10 04:35:04'),
(48, 'this is new', 5, '2016-04-10 04:35:13', '2016-04-10 04:35:13'),
(49, 'this is so cute.. <3 ', 5, '2016-04-10 04:38:39', '2016-04-10 04:38:39'),
(50, 'fdfddf', 5, '2016-04-10 04:46:14', '2016-04-10 04:46:14'),
(51, 'যা পারবে করে দেখাও , যা পারবে না করার দরকার নেই', 9, '2016-04-10 04:50:02', '2016-04-10 04:50:02'),
(52, 'What the post is this!!!', 9, '2016-04-10 05:15:41', '2016-04-10 05:15:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_status` tinyint(1) NOT NULL DEFAULT '0',
  `user_type` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `first_name`, `password`, `user_status`, `user_type`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'hbrawnak@gmail.com', 'Habib', '$2y$10$5XarCXGO8PG7t51YHc5Oj.KBRsLnazIrJhrrdFao7r7k9mT5p3jLi', 0, 1, 'hVP7jgcyA2kJyOV0XBqYD0IVv5E1i2Q3TcgEw20N3GyPnHmyIvCJaNAIRbpb', '2016-03-21 23:58:41', '2016-04-10 05:23:56'),
(5, 'rana@gmail.com', 'Rana', '$2y$10$A6RDSJsPHDx/vNbBfO6u0O5zNwWs2wJnDTAXIo/q42V1SS7oDqRW2', 0, 0, 'vTwc8V2T4vR8TNPDQ3xNcqmtT95gCpbHlfKHlHr54HncjcihpuT3KSuRnH7r', '2016-04-09 07:59:17', '2016-04-10 04:48:08'),
(6, 'nasima@gmail.com', 'Nasima Karim', '$2y$10$O2vS6qOiOMgFPVN4oLQkYOlYqrcPEsfGL4GVML56/QDHWj9UU0Tau', 0, 0, '7X0GVVv5jyqibcH8FSCTq4ajjINw7tS8E0vQ7GUM8z12K4cP8M3YHc8dSsZv', '2016-04-09 08:01:59', '2016-04-09 09:00:51'),
(7, 'black@gmail.com', 'Black Khan', '$2y$10$hSGAGsogNZhMXEa7dSVff.z9QKnKG9sI2RZXE4iPEWzj9dPTqNgQm', 0, 0, '5rOxk3m5MS1kUsoHyv36kPLIJEItgGV0PENbVPGQpzMoC8Nkl95V9MMWmx0a', '2016-04-09 08:02:27', '2016-04-10 00:14:57'),
(8, 'rea@gmail.com', 'Afasan Rea', '$2y$10$3.mo6g1dUnQgfuolCblzu.t2Ta6WmsgzWaU6BuErxUsd0UDyM5auO', 0, 0, 'AUzUcFPjGRhVXwLa1CAvM3GGWD8slcqlyAJzBu165FGAuKL1ixpkQsJ7fZvq', '2016-04-09 09:01:50', '2016-04-10 04:33:14'),
(9, 'naeem@gmail.com', 'Naeem', '$2y$10$ZtHxHKXseA5cmeC8wAJHZunvcLwH3vatO9/y1u/hMxMpiA6uPTjoa', 0, 0, '0RFaqvymMPiRZF2YBejN3NbjAEoO8Rp0eAFEvsy3Ojs7mroSmg72yzrbNOTl', '2016-04-10 04:48:29', '2016-04-10 05:19:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
